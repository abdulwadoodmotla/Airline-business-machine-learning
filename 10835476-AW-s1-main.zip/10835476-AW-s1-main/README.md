# 10835476-AW-S1
6006CEM COURESEWORK
URL of selected dataset:
https://www.kaggle.com/datasets/sjleshrac/airlines-customer-satisfaction/data
